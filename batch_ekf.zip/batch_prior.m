function [err, J] = batch_prior(x_prior, x)
window_size = (size(x, 1) - 2) / 3;
init_state = zeros(5, 1);
J = zeros(5, size(x, 1));
init_state(1:2, 1) = x(1:2, 1);
J(1:2, 1:2) = -eye(2);
init_state(3, 1) = x(2 * window_size + 1, 1);
J(3, 2 * window_size + 1) = -1;
init_state(4, 1) = x(end -1, 1);
J(4, end - 1) = -1;
init_state(5, 1) = x(end, 1);
J(5, end) = -1;
err = x_prior - init_state;

end