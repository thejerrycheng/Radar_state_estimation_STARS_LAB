function [err, F] = batch_f(x)
%% Motion model for 2D radar to radar calibration
window_length = (length(x) - 2) / 3;
err = diff(x(2 * window_length + 1: 3 * window_length));
F = zeros(length(err), length(x));
F_offset = diag(ones(1, window_length - 1), 1);
F(:, 2 * window_length + 1: 3 * window_length) = - eye(window_length - 1, window_length) + F_offset(1:end-1, :);
end