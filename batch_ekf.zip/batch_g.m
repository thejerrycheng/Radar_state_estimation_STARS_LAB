function [err, J] = batch_g(meas, x)
% Measurement Model
% x is the state vector [v(1:window_size); omega(1:window_size); theta_t; theta_BA]
window_size = size(meas, 1) / 4;
unit_t = [cos(x(end - 1, 1)); sin(x(end - 1,1))];
J=zeros(size(meas, 1), size(x, 1));
err = zeros(size(meas, 1), 1);
%Measurements from sensor A
err(1:2 * window_size, 1) = meas(1:2 * window_size, 1) - x(1:2 * window_size, 1);
J(1:2 * window_size, 1:2 * window_size) = -eye(2*window_size);
for i=1:window_size
    index_1 = 2 * i + 2 * window_size - 1; 
    err(index_1: index_1+1, 1) = meas(index_1: index_1+1, 1) - radar_meas(x(2 * i - 1:2 * i, 1) , x(i + 2 * window_size, 1), unit_t, x(end, 1));
    J_sub = -construct_G([x(2 * i - 1:2 * i, 1) ; x(i + 2 * window_size, 1); 0; x(end-1, 1); x(end, 1)]);
    J(index_1: index_1+1, 2 * i - 1:2 * i) = J_sub(3:4, 1:2);
    J(index_1: index_1+1, i + 2 * window_size) = J_sub(3:4, 3);
    J(index_1: index_1+1, end - 1) = J_sub(3:4, end - 1);
    J(index_1: index_1+1, end) = J_sub(3:4, end);
end
return