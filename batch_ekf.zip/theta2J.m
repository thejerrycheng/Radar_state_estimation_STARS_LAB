function J = theta2J(theta)
J = [-sin(theta), cos(theta);...
    -cos(theta), -sin(theta)];
end